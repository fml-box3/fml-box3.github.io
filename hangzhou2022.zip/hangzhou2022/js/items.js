let scale = (screen.availWidth - 50) / 4 / 440;
let main_content = document.getElementById('main_content');
for (let i = 1; i <= 61; i++) {
    let node = document.createElement('div');
    node.classList.add('card');

    let div = document.createElement('div');
    div.classList.add('content');

    let img = document.createElement('img');
    img.src = `img/i${i}.jpg`;
    img.loading = 'lazy';
    img.alt = '赛项' + i;
    img.width = 440 * scale * 0.8;
    img.height = 560 * scale * 0.8;

    div.appendChild(img);
    node.appendChild(div);
    main_content.appendChild(node);
}
