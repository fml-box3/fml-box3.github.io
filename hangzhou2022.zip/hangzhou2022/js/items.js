let scale = (screen.availWidth - 50) / 4 / 440;
let main_content = document.getElementById('items');
for (let i = 1; i <= 61; i++) {
    let node = document.createElement('div');
    node.classList.add('card');

    let div = document.createElement('div');
    div.classList.add('content');

    let a = document.createElement('a');
    a.href = `img/i${i}.jpg`

    let img = document.createElement('img');
    img.src = `img/i${i}.jpg`;
    img.loading = 'lazy';
    img.alt = '赛项' + i + '·图片';
    img.width = 440 * scale * 0.8;
    img.height = 560 * scale * 0.8;

    a.appendChild(img);
    div.appendChild(a);
    node.appendChild(div);
    main_content.appendChild(node);
}
